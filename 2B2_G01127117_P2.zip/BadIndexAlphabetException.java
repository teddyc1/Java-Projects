/**
 * @Author Theodore Church G01127117
 */
public class BadIndexAlphabetException extends AlphabetException {
    //another exception class
    public final int index;
    public final Alphabet a;
    public BadIndexAlphabetException(int index, Alphabet a){
        super("Not in alphabet: no index "+index+" found in "+a.toString()+".");
        this.a = a;
        this.index = index;
    }
}
