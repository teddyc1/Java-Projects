/**
 * @Author Theodore Church G01127117
 */
public class AlphabetException extends RuntimeException {

    //basic exception class, just calls super
    public AlphabetException(String message){
        super(message);
    }
}
