/**
 * @Author Theodore Church G01127117
 */
public class VigenereCipher extends SymmetricCipher {
    protected String password;
    protected int passwordPos;
    public VigenereCipher(String password,Alphabet alphabet){
        super(alphabet);
        this.password = password;
        passwordPos = 0;
    }
    public VigenereCipher(String password){
        super(Alphabet.DEFAULT);
        this.password = password;
        passwordPos = 0;
    }
    public String getPassword(){
        return password;
    }

    @Override
    protected char encrypt1(char c) throws MissingCharAlphabetException {
        //Relies upon password and passwordPos to encrypt a single char. Must increment passwordPos.
        // Will throw MissingCharAlphabetException if any character is found that isn't in the alphabet.
        if(alphabet.indexOf(c)==-1)throw new MissingCharAlphabetException(c,alphabet); //Valid characters only
        int x;
        x = alphabet.indexOf(c) + alphabet.indexOf(password.charAt(passwordPos));
        passwordPos++;
        if(passwordPos > password.length()-1) passwordPos=0; //-1 because overflow erros
        c = alphabet.get(wrapInt(x));
        return c;
    }

    @Override
    protected char decrypt1(char c) throws MissingCharAlphabetException {
        //Relies upon password and passwordPos to decrypt a single char. Must increment passwordPos.
        // Will throw MissingCharAlphabetException if any character is found that isn't in the alphabet.
        if(alphabet.indexOf(c)==-1)throw new MissingCharAlphabetException(c,alphabet);
        int x;
        x = alphabet.indexOf(c) - alphabet.indexOf(password.charAt(passwordPos));
        passwordPos++;
        if(passwordPos > password.length()-1) passwordPos=0;
        c = alphabet.get(wrapInt(x));
        return c;

    }
    @Override
    public String encrypt(String s) throws MissingCharAlphabetException{
        //full string encrypt
        passwordPos = 0;//resets position to 0 for an entire string
        return super.encrypt(s);
    }
    @Override
    public String decrypt(String s) throws MissingCharAlphabetException{
        //full string decrypt
        passwordPos = 0;//resets position to 0 for an entire string
        return super.decrypt(s);
    }
    public String toString(){
        //Vigenere Cipher (password='Cats')
        return ("Vigenere Cipher (password='"+password+"')");
    }
}
