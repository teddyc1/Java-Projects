/**
 * @Author Theodore Church G01127117
 */
public class CaesarCipher extends SymmetricCipher{
    protected int shift;
    public CaesarCipher(int shift, Alphabet alphabet){
        super(alphabet);
        this.shift = shift;
    }
    public CaesarCipher(int shift){
        super(Alphabet.DEFAULT);
        this.shift = shift;
    }
    @Override
    public char encrypt1(char c)throws MissingCharAlphabetException{
        //Encrypts and returns a single character based on the shift and the alphabet in use.
        //Will throw MissingCharAlphabetException if any character is found that isn't in the alphabet.
        int nextPos;
        if(alphabet.indexOf(c)==-1)throw new MissingCharAlphabetException(c,alphabet);//-1 means the character doesn't exist
        else{
            nextPos = rotate(alphabet.indexOf(c),shift);
            c = alphabet.get(nextPos);
            return c;
        }
    }
    @Override
    protected char decrypt1(char c) throws MissingCharAlphabetException {
        //Decrypts and returns a single character based on the shift and the alphabet in use.
        //Will throw MissingCharAlphabetException if any character is found that isn't in the alphabet.
        int nextPos;
        if(alphabet.indexOf(c)==-1)throw new MissingCharAlphabetException(c,alphabet);//-1 means character doesn't exist....
            // this line prob isn't needed but my code currently works and it keeps the tester from trying to decrypt
            // a line that wasn't encrypted by this system.
        else{
            nextPos = rotate(alphabet.indexOf(c),(shift*-1));//We want to decrypt, so instead of shifting right(positive) we shift left(negative)
            c = alphabet.get(nextPos);
            return c;
        }
    }
    public String toString(){
        //Caesar Cipher (shift=2)
        return("Caesar Cipher (shift="+shift+")");
    }

}
