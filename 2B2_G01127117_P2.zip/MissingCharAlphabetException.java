/**
 * @Author Theodore Church G01127117
 */
public class MissingCharAlphabetException extends AlphabetException {
    //another exception class
    public final char offender;
    public final Alphabet a;
    public MissingCharAlphabetException(char offender, Alphabet a){
        ////"Not in alphabet: 'a' not found in Alphabet(ABC)."
        super("Not in alphabet: '"+offender+"' not found in "+a.toString()+".");
        this.offender = offender;
        this.a = a;
    }


}
