/**
 * @Author Theodore Church G01127117
 */

public class Alphabet {

    private String symbols;
    public static final Alphabet DEFAULT = new Alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz 1234567890!@#$%^&*()_+-=[]{}\\|;:'\",./?<>");
    // finish this class definition.

    public Alphabet(String symbols){
        //constructor
        this.symbols = symbols;
    }
    public int indexOf(char c)throws MissingCharAlphabetException{
        //Finds the index of the requested character, throws an exception if not found.
        if(symbols.indexOf(c)==-1) throw new MissingCharAlphabetException(c,new Alphabet(symbols));
        for(int i = 0;i<symbols.toCharArray().length;i++) {
                if (symbols.toCharArray()[i] == c) {
                    return i;
                }
            }
        return -1;//Not found
    }
    public char get(int i)throws BadIndexAlphabetException{
        //finds the character at the requested index, throws an exception if the index is out of bounds
        if(i>symbols.length()-1||i<0) throw new BadIndexAlphabetException(i,new Alphabet(symbols));
        else return symbols.toCharArray()[i];
    }
    public int length(){
        return symbols.length();
    }
    public String getSymbols(){
        return symbols;
    }
    public String toString(){
        return("Alphabet("+symbols+")");
    }
    public boolean equals(Object other){
        //if(!other.getClass().equals(symbols.getClass())){return false;}//Checking if they're both alphabet class
        //This caused a bug on the tester.
        if(other.equals(symbols)){//Checking if strings match
            return true;//Return true
        }
        else return false;//Didn't work
    }
}
