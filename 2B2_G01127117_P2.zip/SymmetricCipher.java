/**
 * @Author Theodore Church G01127117
 */
public abstract class SymmetricCipher extends Cipher {
    protected Alphabet alphabet;//MissingCharAlphabetException
    public SymmetricCipher(Alphabet alphabet){
        //constructor
        this.alphabet = alphabet;
    }
    public int wrapInt(int i){
        //Given an index value that may be outside the range of valid indexes into the alphabet,
        //wrap it back around to a valid index.
        while(i>alphabet.length()-1){ //-1 because of how arrays work, while loop in case the input is much larger
            i=i-alphabet.length();}
        while(i<0) {//while loop in case the input is much lower than valid
            i += alphabet.length();
        }
        return i;
    }
    public int rotate(int index, int shift){
        //Given an index into the alphabet, rotate it around shift times to the resulting valid index into alphabet.
        // When the index is out of bounds in either direction, we wrap around until it's back in range.
        // No matter what index and shift value is given, we should be able to return an answer
        // (assuming the alphabet has a non-zero length! Which it always should).
        return wrapInt(index + shift);
    }
    public Alphabet getAlphabet(){return alphabet;}
    //Child classes must provide an implementation of this; it provides a way to encrypt a single character.
    protected abstract char encrypt1(char c)throws MissingCharAlphabetException;
    protected abstract char decrypt1(char c)throws MissingCharAlphabetException;
    public String encrypt(String s)throws MissingCharAlphabetException{
        //instead of encrypting a single character this encrypts a string of characters. it's a loop of encrypt
        String newString = "";
        for (char c : s.toCharArray()) newString += encrypt1(c);
        return newString;
    }

    public String decrypt(String s)throws MissingCharAlphabetException{
        //same as encrypt only with decrypt
        String newString = "";
        for (char c : s.toCharArray()) newString += decrypt1(c);
        return newString;
    }

}
