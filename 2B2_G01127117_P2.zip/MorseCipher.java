import java.util.Scanner;
/**
 * @Author Theodore Church G01127117
 */
public class MorseCipher extends Cipher {
    public static final String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    public static final String[] codes = {
            ".-",    /* A */    "-...",  /* B */    "-.-.",  /* C */    "-..",   /* D */
            ".",     /* E */    "..-.",  /* F */    "--.",   /* G */    "....",  /* H */
            "..",    /* I */    ".---",  /* J */    "-.-",   /* K */    ".-..",  /* L */
            "--",    /* M */    "-.",    /* N */    "---",   /* O */    ".--.",  /* P */
            "--.-",  /* Q */    ".-.",   /* R */    "...",   /* S */    "-",     /* T */
            "..-",   /* U */    "...-",  /* V */    ".--",   /* W */    "-..-",  /* X */
            "-.--",  /* Y */    "--..",  /* Z */    ".----", /* 1 */    "..---", /* 2 */
            "...--", /* 3 */    "....-", /* 4 */    ".....", /* 5 */    "-....", /* 6 */
            "--...", /* 7 */    "---..", /* 8 */    "----.", /* 9 */    "-----", /* 0 */
    };
    public MorseCipher(){
        //unused constructor
    }

    @Override
    public String encrypt(String plainText) {
        //Converts a string of letters, digits, and spaces to the corresponding morse code representation.
        // All lowercase letters are implicitly converted to uppercase during encryption
        plainText=plainText.toUpperCase();
        for(char n:plainText.toCharArray()){ //Check to make sure that the string contains only valid characters
            if(letters.indexOf(n)==-1&&n!=' '){ //Spaces are valid
                throw new MissingCharAlphabetException(n,new Alphabet(letters));
            }
        }
        String encoded = "";
        int x;
        char[] stored = plainText.toCharArray();//Turning this into an array makes it easy
        for(int i=0;i<stored.length;i++){
            if(stored[i]==' '){//spaces are encoded at 7 spaces
                encoded+="       ";
            }
            else{
                x = letters.indexOf(stored[i]);
                encoded+=(""+codes[x]);
                if(i<stored.length-1&&stored[i+1]!=' '){
                    encoded+="   ";//this adds spaces between letters but only if there's more letters and the next letter isn't a space
                }
            }
        }
        return encoded;
    }

    @Override
    public String decrypt(String cryptText) {
        //Converts a string of morse code representation back to a string of uppercase letters, digits, and spaces.
        // Any letters that were originally lowercase will only appear as uppercase.
        //I couldn't get this to work. :(
        //assumed that the string doesn't need to be tested for character errors
        String decoded = "";
        int spaceCount = 0;
        int x;
        String held = ""; // holding digits
        for(int i = 0;i<cryptText.length();i++){
            char n = cryptText.charAt(i);
            if(n==' '){
                if(spaceCount==3){
                    if (i+1 > cryptText.length()){
                        break;
                    }
                    if(cryptText.charAt(i+1)==' '){
                        //do nothing
                    }
                    else{
                        spaceCount = 0;
                    }
                }
                if(spaceCount==7){
                    decoded+=" ";
                }
                spaceCount++;
            }
            else if (i+1 > cryptText.length()){
                break;
            }
            else if(cryptText.charAt(i+1)==' '){
                x = findCode(held);
                decoded += letters.charAt(x);
            }
            else{
                held += n;
            }
        }
        return decoded;
    }
    public int findCode(String s){
        for(int i = 0;i<codes.length;i++){
            if (codes[i].equals(s)){
                return i;
            }
        }
        return -1;
    }
}

