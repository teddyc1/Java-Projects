/**
 * @Author Theodore Church G01127117
 */
public abstract class Cipher {
    //basic abstract class framework
    public abstract String encrypt(String s);
    public abstract String decrypt(String s);
}
