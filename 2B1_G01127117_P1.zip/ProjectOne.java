import java.util.Scanner;

/**
 * Theodore Church G01127117
 */
public class ProjectOne {

    /*
     * used for testing
     */
//    public static void main(String[] args){
//        int[] tester = {2,4,8,16,32};
//        int[] tester2 = {};
//        int[] tester3 = {1,5,10,2,20};
//        //System.out.print(doubling(tester2));
//        //System.out.print(gradeCheck(82.5,'A'));
//        //System.out.print(sumCapped(tester,21));
//        //System.out.print(largestAscent(tester3));
//        //System.out.print(quadrant(1,-4));
//        //System.out.print(numInRange(2,19,tester3));
//        //System.out.print(mean(tester3));
//        //System.out.print(buildArrayFromInput());
//    }
    public static boolean doubling(int[] values){
        //This method should return true if and only if every successive element in the input array is in ascending order
        // such that each element is twice the value of the element before it, and false otherwise. For example,
        // the array {1, 2, 5, 5, 6, 7, 8, 8, 8} would return false. The array {3, 6, 12, 24, 48, 96} would return true.
        // An empty array should return false.
        if(values.length==0) return false;
        for(int i = values.length-1;i>0;i--){
           if(values[i]!=(values[i-1]*2))return false;
        }
        return true;
    }

    public static boolean gradeCheck(double grade, char letter){
        //assuming the letter is uppercase
        //This method will return true or false based on if the given grade between 0-100 inclusive matches the given
        //letter grade (A,B,C,D,F). Here is the breakdown of grade values to use for this problem:
        //If the grade entered falls outside of the range 0 to 100 inclusive, you should return false.
        if(letter=='A') return (grade >= 90.0 && grade <=100.0);
        else if(letter=='B') return (grade <90.0 && grade >= 80.0);
        else if(letter=='C') return (grade <80.0 && grade >= 70.0);
        else if(letter=='D') return (grade <70.0 && grade >= 60.0);
        else if(letter=='F') return (grade <60.0);
        else return false;
    }

    public static int sumCapped(int[] nums, int x){
        //This method will return the largest sum that is less than or equal x found in one pass of the array.
        // This means that you must check each number in succession to determine whether or not you should add it in.
        // For example, for the array {4, 2, 3, 5} with the value of the paramter x set to 7, the value 6 will be returned.
        // If the array is empty, then the built-in constant Integer.MAX_VALUE may be returned.
        int max = 0;
        if(nums.length==0||nums.length==1){max=Integer.MAX_VALUE; return max;}
        for (int i = 0; i < nums.length; i++) {
            if((max+nums[i])<=x){
                max+=nums[i];
            }
        }
        return max;
    }

    public static int largestAscent(int[] values){
        //Given an array of integers, we can conceptually split it into separate non-decreasing sequences.
        // Each sequence has a first and last item, and thus spans some range of values. Find the sequence that has
        // the largest gap from its beginning low-point to its ending high-point, and return this distance.
        // You may assume that there will always be one element in the array.
        if(values.length<2) return 0;//if there's less than 2 numbers, IE only 1 number doesn't have a range.
        int start = values[0];
        int end = values[1];
        int currentMax = end-start;
        if (values.length<3) return currentMax;
        for(int i=2;i<values.length; i++){
            if(values[i]>end){
                end = values[i];
                if(end-start>currentMax)currentMax = end-start;
            }
            else if(values[i] < end) {
                start = values[i];
                end = values[i];
            }
        }
        return currentMax;
    }

    public static String quadrant(int x, int y){
        //Given integer coordinates for x and y, give back a string that correctly describes what quadrant the point is in.
        if(x==0||y==0) return "none";
        else if(x>0 && y> 0) return "first";
        else if(x<0 && y>0) return "second";
        else if(x<0) return "third";
        else return "fourth";
    }

    public static int numInRange(int a, int b, int[] values){
        //Determines the number of elements from the array of values which have a value within the range [a, b)
        //(that is, between a and b, including a but not including b). For example, if the input array is
        //{1, 2, 3, 4, 2, 3, 4, 3, 4, 4} with a = 2 and b = 4, the result would be 5 (because there are two 2's and three 3's)
        int count=0;
        for(int i: values)if(i>=a&&i<b)count++;
        return count;
    }

    public static double mean(int[] values){
        //Finds the arithmetic mean (the average) of the list of numbers. For example, if the input is {1, 2, 3, 4}, then the mean is 2.5.
        double sum = 0;
        for(int i: values)sum+=i;
        return sum/values.length;
    }

    public static int[] buildArrayFromInput(){
        //For this function, you will practice getting user input to build an array.
        // First, you need to ask the user for the size of the array to build.
        // Then, you need to repeatedly ask the user to fill an array of that size with integers.
        // You should return the array that you built. You can assume the user will always
        // try to build an array with at least one element. This function will be tested manually when grading -
        // there are no tests given for this method.
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Please enter the integer size of the array");
        int size = keyboard.nextInt();
        if (size <0) System.out.println("You know very well we can't have an array with negative elements. Bad.");
        int[] array = new int[size];
        for(int i = 0;i<size;i++){
            System.out.println("Please enter the integer for the next number in the array");
            array[i] = keyboard.nextInt();
        }
        keyboard.close();
        return array;
    }

}