import org.junit.*; // Rule, Test
import org.junit.rules.Timeout;
import static org.junit.Assert.*;

import java.util.*;

import payroll.*;
/*
 *@Author Theodore Church, G01127117
 * I missed 4 failures, I will be commenting about where I think they are
 */
public class PayrollTest {
  public static void main(String args[]){
    org.junit.runner.JUnitCore.main("PayrollTest");
  }
  
  // 1 second max per method tested
  //This is commented out as it causes bugs with my system.
 // @Rule public Timeout globalTimeout = Timeout.seconds(1);

  // BEGIN TESTS HERE.
  @Test
  public void testDict(){
    //Tests the instantiation of the base class.
    Dict testDict = new Dict();
    int n = testDict.size();
    assertEquals(0,n); //There should be no entries so far
  }
  @Test
  public void testPut(){
    Dict<String,Integer> testDict = new Dict<String,Integer>();
    testDict.put("one", 1);
    assertEquals(1, testDict.size());
    try{
      //Tests Null Values
      testDict.put(null,2);
      assertEquals(1,2);
    }
    catch(Exception n){
      //This should be caught and not allowed to be added
      assertEquals(1, 1);
    }

    try{
      //Testing multiple size, testing get, testing value changing with the same key
      testDict.put("two",2);
      testDict.put("three",3);
      assertEquals(3,testDict.size());
      int j = testDict.get("one");//There might be other errors with get, I didn't test this as well as I'd have liked.
      assertEquals(1,j);
      testDict.put("one",3);
      j = testDict.get("one");
      assertEquals(3,j);
    }
    catch(Exception E){
      assertEquals(1,0); //I don't think this is needed anymore, the code aboved changed and I think this was left in by accident.
    }
    try{
      testDict.get(null);//testing null
      assertEquals(1,2);
    }
    catch(Exception e){
      assertEquals(1,1);
    }
    Dict<String,Integer> test2 = new Dict<String,Integer>();
    try{
      test2.put(" ",1); //This works, but I don't think it should. I think there's an issue in either this class or payroll with string names, but I couldn't find it in time
      assertEquals("{( :1)}",test2.toString());
    }
    catch(Exception e){
      //assertEquals(1,2);
    }
  }
  @Test
  public void testHas(){
    //Tested t/f and t/f after manipulation of data. I don't think there's an error here but I could be wrong.
    Dict<String,Integer> testDict = new Dict<String,Integer>();
    testDict.put("one",1);
    assertEquals(true,testDict.has("one"));
    assertEquals(false,testDict.has("two"));
    testDict.put("two",2);
    testDict.put("three",3);
    assertEquals(true,testDict.has("two"));
    assertEquals(false,testDict.has("four"));
    try{
      testDict.has(null);
      assertEquals(1,2);
    }
    catch(Exception e){
      assertEquals(1,1);
    }
  }
  @Test
  public void testPop(){
    //There's a small chance there's an error here, I didn't test pop that well, I should have tested what happens when you pop everything.
    Dict<String,Integer> testDict = new Dict<String,Integer>();
    testDict.put("one",1);
    testDict.put("two",2);
    testDict.put("three",3);
    testDict.pop("two");
    assertEquals(2,testDict.size());
    try{
      testDict.pop("four");
      assertEquals(5,6);//fail
    }
    catch(Exception e){
      assertEquals(1,1);//caught an out of bounds pop, good.
    }
    try{
      testDict.pop(null);
      assertEquals(5,6);//fail
    }
    catch(Exception e){
      assertEquals(1,1);//caught null pop
    }
  }
  @Test
  public void testList(){
    //Tests what comes out of the list command, there might be an error here with formatting or the string names. I doubt it.
    Dict<String,Integer> testDict = new Dict<String,Integer>();
    testDict.put("one",1);
    testDict.put("two",2);
    testDict.put("three",3);
    List testList = testDict.keys();
    assertEquals(3,testList.size());
    Dict<String,Integer> testDict2 = new Dict<String,Integer>();
    List testList2 = testDict.keys(); //Testing an empty list. I didn't check this well enough.
    assertEquals(3,testList.size());
  }
  @Test
  public void testToString(){
    //Given how many bugs I usually have with tostring, I think there's an issue here,maybe with get, but I don't know. I should have tested this more.
    Dict<String,Integer> testDict = new Dict<String,Integer>();
    testDict.put("one",1);
    testDict.put("two",2);
    testDict.put("three",3);
    assertEquals("{(one:1),(two:2),(three:3)}",testDict.toString());
    testDict.clear();
    assertEquals("{}",testDict.toString());
  }
  /* Payroll tests
   *
   */
  @Test
  public void testPayroll(){
    //tests making a new payroll, and a payroll with a dict
    Payroll empty = new Payroll();
    Dict<String,Integer> testDict = new Dict<String,Integer>();
    testDict.put("Joe",10);
    testDict.put("Mark",15);
    testDict.put("Zuck",1000);
    Payroll testPay = new Payroll(testDict);
    assertEquals(3,testPay.employees().size());
    String[] nameTest = {"Joe","Mark","Zuck"};
    for(int i = 0;i<3;i++){
      assertEquals(nameTest[i], testPay.employees().get(i));
    }
  }
  @Test
  public void testFire(){
    //tests firing employees
    Dict<String,Integer> testDict = new Dict<String,Integer>();
    testDict.put("Joe",10);
    testDict.put("Mark",15);
    testDict.put("Zuck",1000);
    Payroll testPay = new Payroll(testDict);
    assertEquals(false,testPay.fire("Kevin"));
    assertEquals(3,testPay.employees().size());//make sure no employee was removed
    assertEquals(true,testPay.fire("Joe"));
    assertEquals(2,testPay.employees().size()); //make sure an emploree was removed
  }
  @Test
  public void testSalary(){
    //This should have been broken up into smaller tests for unit testing
    //tests get salary, give raise, and monthly expense
    Dict<String,Integer> testDict = new Dict<String,Integer>();
    testDict.put("Joe",10);
    testDict.put("Mark",15);
    testDict.put("Zuck",1000);
    Payroll testPay = new Payroll(testDict);
    assertEquals(10,testPay.getSalary("Joe"));
    try{
      testPay.getSalary("kevin");
      assertEquals(1,2);//fail
    }
    catch(Exception e){
      assertEquals(1,1);//Kevin doesn't work for us
    }
    try{
      testPay.getSalary(null);
    }
    catch(Exception e){
      assertEquals(1,1);//true
    }
    //topsalary
    assertEquals(1000,testPay.topSalary());
    Payroll noemptest = new Payroll();
    assertEquals(0,noemptest.topSalary());
    //raises
    testPay.giveRaise("Joe",.10);
    assertEquals(11,testPay.getSalary("Joe"));
    testPay.giveRaise(1);
    assertEquals(22,testPay.getSalary("Joe"));
    assertEquals(30,testPay.getSalary("Mark"));
    assertEquals(2000,testPay.getSalary("Zuck"));
    try{
      testPay.giveRaise(-1);
      assertEquals(1,2);//Fail, can't give neg raise
    }
    catch(Exception e){
      assertEquals(1,1);
    }
    try{
      testPay.giveRaise("Kevin",12.4);
      assertEquals(1,2);//fail, kevin doesn't exist
    }
    catch(Exception e){
      assertEquals(1,1);//kevin doesn't exist
    }
    try{
      testPay.giveRaise("Joe",-1);
      assertEquals(1,2);//Fail, can't give neg raise
    }
    catch(Exception e) {
      assertEquals(1, 1);
    }
    try{
      testPay.giveRaise(null,1.4);
      assertEquals(1,2);//Fail, null name
    }
    catch(Exception e) {
      assertEquals(1, 1);
    }
    //expenses
    //Given how many other tests i've run for this in testBig this REALLY should have been it's own class
    Payroll monthlytest = new Payroll();
    assertEquals(0,monthlytest.monthlyExpense());
    assertEquals(171,testPay.monthlyExpense());
    testPay.giveRaise("Joe",.5);
    assertEquals(172,testPay.monthlyExpense());
    testPay.giveRaise("Joe",.5);
    assertEquals(50,testPay.getSalary("Joe"));
    testPay.giveRaise(.25);
    assertEquals(38,testPay.getSalary("Mark"));
    assertEquals(63,testPay.getSalary("Joe"));
    assertEquals(2500,testPay.getSalary("Zuck"));
    testPay.giveRaise("Joe",.05);
    assertEquals(67,testPay.getSalary("Joe"));
  }
  @Test
  public void testHire(){
    //I think this is where another error is, I think an empty or open string will cause a bug but I didn't have time to check
    //Checks hiring, makes sure the employee exists, their salary is right, and that when you hire with the same key that the value is overwritten
    Payroll testHire = new Payroll();
    testHire.hire("Joe",10);
    assertEquals(1,testHire.employees().size());
    testHire.hire("Joe",15);
    assertEquals(15,testHire.getSalary("Joe"));
    try{
      testHire.hire(null,15);
      assertEquals(1,2);
    }
    catch(Exception e){
      assertEquals(1,1);
    }
    try{
      testHire.hire("Mark",-1);
      assertEquals(1,2);
    }
    catch(Exception e){
      assertEquals(1,1);
    }
  }
  @Test
  public void testEmptyPayroll(){
    //These tests are made for testing an empty payroll to see what does and doesn't work
    Payroll testP = new Payroll();
    assertEquals(0,testP.employees().size());
//    try{ ///Didn't work,
//      testP.giveRaise(0.05);
//      assertEquals(1,2);//No employees to give a raise to.
//    }
//    catch(Exception e){
//      assertEquals(1,1);
//    }
    assertEquals(0,testP.topSalary());
    assertEquals(0,testP.monthlyExpense());
    testP.hire("Joe",0);
    assertEquals(0,testP.monthlyExpense());
    testP.giveRaise(0);
    assertEquals(0,testP.getSalary("Joe"));
    testP.giveRaise("Joe",0);
    assertEquals(0,testP.getSalary("Joe"));
    testP.hire("John",0);
    testP.hire("Mike",0);
    testP.giveRaise(0);
    assertEquals(0,testP.getSalary("John"));
    assertEquals(0,testP.monthlyExpense());
    assertEquals(0,testP.topSalary());
  }
  @Test
  public void testBig(){
    //for testing big numbers
    //Many of these tests(or previous iterations of) caused all test cases to fail.
    Dict<String,Integer> testDict = new Dict<String,Integer>();
    testDict.put("Joe",1000000);//1m
    testDict.put("Mark",1500000);//1.5m
    testDict.put("Zuck",Integer.MAX_VALUE);//causes all implementations to fail
    Payroll testPay = new Payroll(testDict);
    testPay.giveRaise("Joe",0.0001);
    assertEquals(1000100,testPay.getSalary("Joe"));
    testPay.giveRaise("Mark", 1.105);
    assertEquals(3157500,testPay.getSalary("Mark"));

 //   assertEquals(179165313,testPay.monthlyExpense()); causes an overflow error that catches all test cases
  }
}